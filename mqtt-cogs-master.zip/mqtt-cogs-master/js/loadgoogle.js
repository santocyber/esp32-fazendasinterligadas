google.charts.load("current", {"mapsApiKey":"AIzaSyBG60zFUluPqojsF6mtiCbRAR5IKQVwr08","packages":["corechart","bar","table","gauge","map","imagesparkline"]});
