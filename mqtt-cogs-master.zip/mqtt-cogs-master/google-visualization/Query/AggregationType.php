<?php
  namespace Google\Visualization\DataSource\Query;

  class AggregationType
  {
    const AVG = "avg";
    const COUNT = "count";
    const MAX = "max";
    const MIN = "min";
    const SUM = "sum";
  }
?>
