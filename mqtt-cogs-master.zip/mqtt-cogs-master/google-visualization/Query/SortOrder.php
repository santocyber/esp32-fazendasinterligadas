<?php
  namespace Google\Visualization\DataSource\Query;

  class SortOrder
  {
    const ASCENDING = "asc";
    const DESCENDING = "desc";
  }
?>
