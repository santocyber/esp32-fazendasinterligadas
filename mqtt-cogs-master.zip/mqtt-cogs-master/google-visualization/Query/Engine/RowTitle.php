<?php
  namespace Google\Visualization\DataSource\Query\Engine;

  class RowTitle
  {
    public $values;

    public function __construct($values)
    {
      $this->values = $values;
    }
  }
?>
