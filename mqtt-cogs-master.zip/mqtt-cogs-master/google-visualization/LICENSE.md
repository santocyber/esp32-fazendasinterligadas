This is a derivative of [google-visualization-java](https://code.google.com/p/google-visualization-java/), which uses the [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0)
