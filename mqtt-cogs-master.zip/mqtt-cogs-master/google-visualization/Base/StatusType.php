<?php
  namespace Google\Visualization\DataSource\Base;

  class StatusType
  {
    const OK = "OK";
    const ERROR = "Error";
    const WARNING = "Warning";
  }
?>
