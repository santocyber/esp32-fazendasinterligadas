<?php
  namespace Google\Visualization\DataSource\Util\Pdo;

  interface PdoDataSourceHelperInterface
  {
    static function validateDriver($driver);
  }
?>
