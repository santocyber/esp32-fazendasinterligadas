<?php
  namespace Google\Visualization\DataSource;

  class Capabilities
  {
    const SQL = "SQL";
    const SORT_AND_PAGINATION = "Sort and pagination";
    const SELECT = "Select";
    const ALL = "All";
    const NONE = "None";
  }
?>
