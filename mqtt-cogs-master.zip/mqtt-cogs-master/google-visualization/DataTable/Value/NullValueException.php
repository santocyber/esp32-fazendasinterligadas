<?php
  namespace Google\Visualization\DataSource\DataTable\Value;

  use RuntimeException;

  class NullValueException extends RuntimeException
  {

  }
?>
